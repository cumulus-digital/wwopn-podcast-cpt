<?php
	namespace WWOPN_Podcast;
?>
<form name="wpn-findpost" id="wpn-findpost" method="post" action="">
	<input type="hidden" name="feature_position" value="">
    <?php \find_posts_div(); ?>
</form>
